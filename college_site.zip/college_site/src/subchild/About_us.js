import React from 'react';
const About_us = () =>{
  return (
    <div>
      <h3>About us</h3>
    </div>
  );
}
export default About_us;
