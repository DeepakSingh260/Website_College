import React from 'react';
const Departments = () =>{
  return (
    <div>
      <h3>Departments</h3>
      
    </div>
  );
}
export default Departments;

