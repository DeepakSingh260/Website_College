import React from 'react';
const Academics = () =>{
  return (
    <div>
      <h3>Academics</h3>
      
    </div>
  );
}
export default Academics;
