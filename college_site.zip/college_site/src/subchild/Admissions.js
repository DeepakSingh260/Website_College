import React from 'react';
const Admissions = () =>{
  return (
    <div>
      <h3>Admissions</h3>
      
    </div>
  );
}
export default Admissions;

Admissions.js